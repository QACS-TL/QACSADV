using ZooTzarLibrary;

namespace ZooTests
{
    public class UnitTest1
    {
        [Fact]
        public void AnimalConstructorTest()
        {
            //Arrange
            string expectedName = "Anon";
            int expectedAge = 33;



            //Act
            Animal a = new Animal();

            //Assert
            Assert.Equal(expectedName, a.Name);
            Assert.Equal(expectedAge, a.Age);

        }

        [Fact]
        public void ElephantConstructorTest()
        {
            //Arrange
            string expectedName = "Anon";
            int expectedAge = 33;

            //Act
            Animal a = new Elephant();

            //Assert
            Assert.Equal(expectedName, a.Name);
            Assert.Equal(expectedAge, a.Age);

        }
    }
}