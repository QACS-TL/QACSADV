﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace CompositePublisherBook
{
    public abstract class Text
    {
        public string Name { get; set; }
        public string Blurb { get; set; }
        public Text(string name, string blurb)
        {
            this.Name = name; 
            this.Blurb = blurb; 
        }
        public abstract void Add(Text component);
        public abstract void Remove(Text component);
        public abstract void Display(int depth);
    }
}
