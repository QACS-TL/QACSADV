﻿using CommandPatternUsingDelegate;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace CommandPatternUsingDelegate {
    public delegate void LightController();

    public class Program {
        public static void Main() {
            Light light = new Light();

            LightController lightOn = light.TurnOn;
            LightController lightOff = light.TurnOff;
            LightController lightToggle = light.Toggle;

            RemoteControl control = new RemoteControl(lightOn, lightOff, lightToggle);
            control.PressOnButton();   // Output: The light is on
            control.PressOffButton();  // Output: The light is off
            control.PressToggleButton();  // Output: The light is on
            control.PressToggleButton();  // Output: The light is off

            control.PressOffButton();  // Output: NO OUTPUT
            control.PressOnButton();   // Output: The light is on
            control.PressOnButton();   // Output: NO OUTPUT
        }
    }
}

