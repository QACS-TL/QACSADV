﻿This code is a textbook demonstration of a WinForms deadlock
The UI freezes when you click btnThread because of a threading deadlock between the UI thread and a background thread.

Let’s walk through it step by step.

What happens when you click btnThread
1️. You are on the UI thread
private void btnThread_Click(object sender, System.EventArgs e)
{
    Thread t = new Thread(new ThreadStart(Deadlock));
    t.IsBackground = true;
    t.Start();
    t.Join();   // ❌ BLOCKS THE UI THREAD
}


The UI thread starts a background thread (t)

Then it immediately calls t.Join()

Join() means:
- “UI thread, wait here until thread t finishes”

At this point:

❌ UI thread is blocked

❌ UI thread cannot process messages, repaint, or handle Invoke

2️. The background thread starts running Deadlock()
private void Deadlock()
{
    ClockTick(null);
}


This background thread calls ClockTick.

3️. ClockTick tries to update the UI
private void ClockTick(object o)
{
    if (InvokeRequired)
        Invoke(new TickTock(SetClockText));
    else
        SetClockText();
}


Because this code is not running on the UI thread:

InvokeRequired == true

It calls Invoke(SetClockText)

Important detail:

Invoke is synchronous
It blocks until the UI thread executes SetClockText.

4️. DEADLOCK 💀

Now we have a classic circular wait:

Thread	Waiting for
UI thread -	Waiting for background thread to finish (Join())
Background thread - Waiting for UI thread to process Invoke()

Neither can proceed.

- Both threads are waiting on each other forever

That’s why:

The UI freezes

The clock stops updating

The app never recovers

Why btnSleep also freezes (but differently)
private void btnSleep_Click(object sender, System.EventArgs e)
{
    Thread.Sleep(5000);
}


This freezes the UI because:

You directly put the UI thread to sleep

No deadlock — just a blocked UI thread

The Core Rule You’re Violating

❌ Never block the UI thread
❌ Never call Thread.Join() on the UI thread
❌ Never synchronously Invoke() from a thread the UI is waiting on

How to Fix btnThread_Click
✔️ Option 1: Don’t call Join()
private void btnThread_Click(object sender, System.EventArgs e)
{
    Thread t = new Thread(Deadlock);
    t.IsBackground = true;
    t.Start();
}


Now:

UI thread remains responsive

Background thread can invoke UI safely

✔️ Option 2: Use BeginInvoke instead of Invoke
private void ClockTick(object o)
{
    if (InvokeRequired)
        BeginInvoke(new TickTock(SetClockText)); // non-blocking
    else
        SetClockText();
}


BeginInvoke:

Does not wait for the UI thread

Avoids deadlock

✔️ Option 3: Use modern async/await (recommended today)
private async void btnThread_Click(object sender, EventArgs e)
{
    await Task.Run(() =>
    {
        ClockTick(null);
    });
}


No blocking. No deadlock. Clean and safe.

Final Summary

The UI freezes because:

btnThread_Click blocks the UI thread with Thread.Join()

The background thread calls Invoke()

Invoke() needs the UI thread

The UI thread is blocked

Deadlock

This code is actually an excellent teaching example of:

Why blocking the UI thread is dangerous

Why Invoke vs BeginInvoke matters

Why Join() should never be used on the UI thread