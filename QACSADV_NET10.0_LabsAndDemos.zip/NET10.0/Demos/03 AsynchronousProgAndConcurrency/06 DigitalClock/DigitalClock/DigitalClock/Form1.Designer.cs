﻿namespace DigitalClock
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblClock = new Label();
            btnSleep = new Button();
            btnThread = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            timer2 = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // lblClock
            // 
            lblClock.BackColor = Color.Black;
            lblClock.BorderStyle = BorderStyle.Fixed3D;
            lblClock.Font = new Font("Courier New", 48F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblClock.ForeColor = Color.Lime;
            lblClock.Location = new Point(0, 2);
            lblClock.Name = "lblClock";
            lblClock.Size = new Size(434, 87);
            lblClock.TabIndex = 0;
            lblClock.Text = "00:00:00";
            lblClock.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnSleep
            // 
            btnSleep.Font = new Font("Lucida Console", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSleep.Location = new Point(49, 103);
            btnSleep.Name = "btnSleep";
            btnSleep.Size = new Size(133, 49);
            btnSleep.TabIndex = 1;
            btnSleep.Text = "Sleep";
            btnSleep.Click += btnSleep_Click;
            // 
            // btnThread
            // 
            btnThread.Font = new Font("Lucida Console", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnThread.Location = new Point(212, 103);
            btnThread.Name = "btnThread";
            btnThread.Size = new Size(169, 49);
            btnThread.TabIndex = 1;
            btnThread.Text = "DeadLock!";
            btnThread.Click += btnThread_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSleep);
            Controls.Add(lblClock);
            Controls.Add(btnThread);
            Name = "Form1";
            Text = "QA Digital Clock";
            Load += Form1_Load;
            ResumeLayout(false);
        }
        private System.Windows.Forms.Label lblClock;
        private System.Windows.Forms.Button btnThread;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button btnSleep;
        #endregion
    }
}
