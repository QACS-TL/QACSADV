namespace ManagingResources
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClickMe_Click(object sender, EventArgs e)
        {
            using (ResourceManagementClass rmc = new ResourceManagementClass())
            {
                rmc.Use();
            }

            ResourceManagementClass rmc2 = new ResourceManagementClass();
            rmc2.Use();

        }

        private void btnGC_Click(object sender, EventArgs e)
        {
            System.GC.Collect();
        }
    }
}
