﻿namespace ManagingResources
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnClickMe = new Button();
            btnGC = new Button();
            SuspendLayout();
            // 
            // btnClickMe
            // 
            btnClickMe.Location = new Point(110, 80);
            btnClickMe.Name = "btnClickMe";
            btnClickMe.Size = new Size(154, 54);
            btnClickMe.TabIndex = 0;
            btnClickMe.Text = "Click Me!";
            btnClickMe.UseVisualStyleBackColor = true;
            btnClickMe.Click += btnClickMe_Click;
            // 
            // btnGC
            // 
            btnGC.Location = new Point(110, 187);
            btnGC.Name = "btnGC";
            btnGC.Size = new Size(154, 53);
            btnGC.TabIndex = 1;
            btnGC.Text = "GC";
            btnGC.UseVisualStyleBackColor = true;
            btnGC.Click += btnGC_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnGC);
            Controls.Add(btnClickMe);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnClickMe;
        private Button btnGC;
    }
}
