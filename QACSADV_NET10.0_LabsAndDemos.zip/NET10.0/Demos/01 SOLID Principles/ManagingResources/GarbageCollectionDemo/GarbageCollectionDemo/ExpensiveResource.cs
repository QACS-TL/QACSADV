﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GarbageCollectionDemo
{
    public class ExpensiveResource : IDisposable
    {
        private bool _disposed = false;
        private IntPtr _unmanagedMemory; // Simulated unmanaged resource

        public ExpensiveResource()
        {
            // Simulate allocating some unmanaged memory
            _unmanagedMemory = System.Runtime.InteropServices.Marshal.AllocHGlobal(1024);
            Console.WriteLine("ExpensiveResource created and unmanaged memory allocated.");
        }

        public void Use()
        {
            if (_disposed)
                throw new ObjectDisposedException(nameof(ExpensiveResource));

            Console.WriteLine("Using expensive resource...");
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this); // Avoid finalizer if already cleaned up
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    // Dispose managed resources here if any
                }

                // Free unmanaged memory
                System.Runtime.InteropServices.Marshal.FreeHGlobal(_unmanagedMemory);
                Console.WriteLine("Unmanaged memory freed manually via Dispose().");

                _disposed = true;
            }
        }

        ~ExpensiveResource()
        {
            Console.WriteLine("Finalizer called! Resource was not disposed manually.");
            Dispose(false); // Clean up in case Dispose wasn't called
        }
    }
}
