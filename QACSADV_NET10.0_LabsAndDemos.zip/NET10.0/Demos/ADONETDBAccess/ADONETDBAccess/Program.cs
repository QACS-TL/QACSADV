using ADONETDBAccess.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddDbContext<NorthwindContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("sqlnorthwind")));

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//builder.Services.AddDbContext<NorthwindContext>(options =>
//    options.UseSqlServer(
//        builder.Configuration.GetConnectionString("sqlnorthwind")));




//builder.Services.AddDbContext<NorthwindContext>(options =>
//  options.UseSqlServer(
//    builder.Configuration.GetConnectionString("sqlnorthwind")));


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    using (var scope = app.Services.CreateScope())
    {
        var buyerContext =
            scope.ServiceProvider.GetRequiredService<NorthwindContext>();
        buyerContext.Database.EnsureCreated();
        //buyerContext.Seed();
    }

    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
